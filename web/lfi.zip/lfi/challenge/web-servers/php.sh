#!/bin/bash
exec php -S 0.0.0.0:1337 -t /web-apps

